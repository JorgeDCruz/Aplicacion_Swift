//
//  LectionController.swift
//  App_Etapa3
//
//  Created by alumno on 03/11/22.
//

import UIKit

class LectionController: UIViewController, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 16
    }
    
    @IBOutlet weak var LectionTable: UITableView!
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Boton1", for: indexPath) as! LectionTable
        cell.nombreDelBoton.titleLabel?.text = "Botonaso " + String(indexPath.row)
        if indexPath.row%4 == 0 || indexPath.row == 0{
            cell.nombreDelBoton.backgroundColor = .gray
            cell.nombreDelBoton.titleLabel?.textColor = .white
            cell.nombreDelBoton.titleLabel?.text = "Nivel " + String((indexPath.row / 4) + 1)
        }
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        LectionTable.dataSource = self
    }
    
}
