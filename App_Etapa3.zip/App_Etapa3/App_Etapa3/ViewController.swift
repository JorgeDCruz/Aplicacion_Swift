//
//  ViewController.swift
//  App_Etapa3
//
//  Created by alumno on 02/11/22.
//

import UIKit
import DropDown

class ViewController: UIViewController {
    
    let dropDown = DropDown()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func companySelect(_ sender: UIButton) {
    }
    @IBAction func CompanySelect(_ sender: UIButton) {
        dropDown.dataSource = ["Tec de Monterrey", "John Deere", "Cisco"]//4
            dropDown.anchorView = sender //5
            dropDown.bottomOffset = CGPoint(x: 0, y: sender.frame.size.height) //6
            dropDown.show() //7
            dropDown.selectionAction = { [weak self] (index: Int, item: String) in //8
              guard let _ = self else { return }
              sender.setTitle(item, for: .normal) //9
            }
    }
    /*
    
    @IBAction func CompanySelect(_ sender: Any) {
        
    }
    */
    @IBAction func LoginButton(_ sender: Any) {
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let imageViewController = storyBoard.instantiateViewController(withIdentifier: "SignUpView")
        imageViewController.modalPresentationStyle = .fullScreen
        self.present(imageViewController, animated: true)
    }
    
}

