//
//  LectionTable.swift
//  App_Etapa3
//
//  Created by alumno on 03/11/22.
//

import UIKit

class LectionTable: UITableViewCell {
    
    @IBOutlet weak var nombreDelBoton: UIButton!
    @IBOutlet weak var textoDelBoton: UILabel!
    
}

